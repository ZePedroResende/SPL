class Word:
    def __init__(self, sinonimos, semantica=None):
        self.sinonimos = sinonimos
        self.semantica = semantica
