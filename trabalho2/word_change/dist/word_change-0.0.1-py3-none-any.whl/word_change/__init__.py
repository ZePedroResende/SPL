#!/usr/bin/python3

from .createdb import create
from .createdb import generator
from .createdb import printdb

from .parser import creator
from .parser import replace_latex
from .parser import spotlight_latex
from .parser import replace
from .parser import spotlight

from .Word import Word